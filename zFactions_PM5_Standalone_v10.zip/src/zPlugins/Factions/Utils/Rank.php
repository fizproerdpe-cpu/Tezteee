<?php

declare(strict_types=1);

namespace zPlugins\Factions\Utils;

class Rank {

    public const MEMBER   = 0;
    public const OFFICER  = 1;
    public const COLIDER  = 2;  // Co-Líder
    public const LEADER   = 3;

    public static function getName(int $rank): string {
        return match($rank) {
            self::MEMBER  => "§7Membro",
            self::OFFICER => "§aOficial",
            self::COLIDER => "§bCo-Líder",
            self::LEADER  => "§6Líder",
            default       => "§7Desconhecido"
        };
    }

    public static function getTag(int $rank): string {
        return match($rank) {
            self::MEMBER  => "§7[M]",
            self::OFFICER => "§a[O]",
            self::COLIDER => "§b[CL]",
            self::LEADER  => "§6[L]",
            default       => "§7[?]"
        };
    }

    public static function canManage(int $rank): bool {
        return $rank >= self::COLIDER;
    }

    public static function isLeader(int $rank): bool {
        return $rank === self::LEADER;
    }

    public static function isCoLeader(int $rank): bool {
        return $rank >= self::COLIDER;
    }
}
