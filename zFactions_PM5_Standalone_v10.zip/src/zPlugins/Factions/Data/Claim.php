<?php

declare(strict_types=1);

namespace zPlugins\Factions\Data;

class Claim {

    private int    $chunkX;
    private int    $chunkZ;
    private string $world;
    private string $factionName;
    private int    $claimedAt;

    public function __construct(int $chunkX, int $chunkZ, string $world, string $factionName) {
        $this->chunkX      = $chunkX;
        $this->chunkZ      = $chunkZ;
        $this->world       = $world;
        $this->factionName = $factionName;
        $this->claimedAt   = time();
    }

    public function getChunkX(): int        { return $this->chunkX; }
    public function getChunkZ(): int        { return $this->chunkZ; }
    public function getWorld(): string      { return $this->world; }
    public function getFactionName(): string{ return $this->factionName; }
    public function getClaimedAt(): int     { return $this->claimedAt; }

    public function getKey(): string {
        return "{$this->world}:{$this->chunkX}:{$this->chunkZ}";
    }

    public static function makeKey(string $world, int $chunkX, int $chunkZ): string {
        return "{$world}:{$chunkX}:{$chunkZ}";
    }

    public function toArray(): array {
        return [
            "chunkX"      => $this->chunkX,
            "chunkZ"      => $this->chunkZ,
            "world"       => $this->world,
            "factionName" => $this->factionName,
            "claimedAt"   => $this->claimedAt
        ];
    }

    public static function fromArray(array $data): self {
        $c = new self($data["chunkX"], $data["chunkZ"], $data["world"], $data["factionName"]);
        $c->claimedAt = $data["claimedAt"] ?? time();
        return $c;
    }
}
