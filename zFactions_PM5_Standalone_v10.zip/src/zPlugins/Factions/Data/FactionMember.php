<?php

declare(strict_types=1);

namespace zPlugins\Factions\Data;

use zPlugins\Factions\Utils\Rank;

class FactionMember {

    private string $name;
    private string $uuid;
    private int    $rank;
    private float  $power;
    private int    $kills;
    private int    $deaths;
    private int    $joinTime;

    public function __construct(string $name, string $uuid, int $rank = Rank::MEMBER, float $power = 10.0) {
        $this->name     = $name;
        $this->uuid     = $uuid;
        $this->rank     = $rank;
        $this->power    = $power;
        $this->kills    = 0;
        $this->deaths   = 0;
        $this->joinTime = time();
    }

    public function getName(): string   { return $this->name; }
    public function getUUID(): string   { return $this->uuid; }
    public function getRank(): int      { return $this->rank; }
    public function getPower(): float   { return $this->power; }
    public function getKills(): int     { return $this->kills; }
    public function getDeaths(): int    { return $this->deaths; }
    public function getJoinTime(): int  { return $this->joinTime; }

    public function setRank(int $rank): void   { $this->rank = $rank; }
    public function setPower(float $p): void   { $this->power = max(-10.0, min(10.0, $p)); }
    public function addPower(float $p): void   { $this->setPower($this->power + $p); }
    public function reducePower(float $p): void{ $this->setPower($this->power - $p); }
    public function addKill(): void            { $this->kills++; $this->addPower(1.0); }
    public function addDeath(): void           { $this->deaths++; $this->reducePower(1.0); }

    public function canManage(): bool {
        return Rank::canManage($this->rank);
    }

    public function isLeader(): bool {
        return Rank::isLeader($this->rank);
    }

    public function isCoLeader(): bool {
        return Rank::isCoLeader($this->rank);
    }

    public function toArray(): array {
        return [
            "name"     => $this->name,
            "uuid"     => $this->uuid,
            "rank"     => $this->rank,
            "power"    => $this->power,
            "kills"    => $this->kills,
            "deaths"   => $this->deaths,
            "joinTime" => $this->joinTime
        ];
    }

    public static function fromArray(array $data): self {
        $m = new self($data["name"], $data["uuid"], $data["rank"] ?? Rank::MEMBER, $data["power"] ?? 10.0);
        $m->kills    = $data["kills"]    ?? 0;
        $m->deaths   = $data["deaths"]   ?? 0;
        $m->joinTime = $data["joinTime"] ?? time();
        return $m;
    }
}
