<?php

declare(strict_types=1);

namespace zPlugins\Factions\Data;

use zPlugins\Factions\Utils\Rank;

class Faction {

    private string $name;
    private string $description;
    private string $tag;
    private float  $money;
    private int    $createdAt;
    private bool   $open;
    private int    $kills;
    private int    $deaths;

    /** @var FactionMember[] */
    private array $members = [];

    /** @var Claim[] */
    private array $claims = [];

    /** @var array[] spawners armazenados: [type => count, x, y, z, world] */
    private array $spawners = [];

    /** @var string[] jogadores convidados */
    private array $invites = [];

    /** @var string[] jogadores com fly ativo */
    private array $flyPlayers = [];

    /** @var array<string, int> chunkKey => timestamp da explosão */
    private array $recentExplosions = [];

    /** @var string[] nomes de facções aliadas */
    private array $allies = [];

    public function __construct(string $name, string $description = "", string $tag = "") {
        $this->name        = $name;
        $this->description = $description;
        $this->tag         = $tag ?: strtoupper(substr($name, 0, 3));
        $this->money       = 0.0;
        $this->createdAt   = time();
        $this->open        = false;
        $this->kills       = 0;
        $this->deaths      = 0;
    }

    // ─── Getters básicos ───────────────────────────────────────────────────────

    public function getName(): string        { return $this->name; }
    public function getDescription(): string { return $this->description; }
    public function getTag(): string         { return $this->tag; }
    public function getMoney(): float        { return $this->money; }
    public function getCreatedAt(): int      { return $this->createdAt; }
    public function isOpen(): bool           { return $this->open; }
    public function getKills(): int          { return $this->kills; }
    public function getDeaths(): int         { return $this->deaths; }

    // ─── Setters ───────────────────────────────────────────────────────────────

    public function setDescription(string $d): void { $this->description = $d; }
    public function setTag(string $t): void          { $this->tag = $t; }
    public function setOpen(bool $o): void           { $this->open = $o; }
    public function addMoney(float $amount): void    { $this->money += $amount; }
    public function removeMoney(float $amount): void { $this->money = max(0, $this->money - $amount); }
    public function addKill(): void                  { $this->kills++; }
    public function addDeath(): void                 { $this->deaths++; }

    // ─── Membros ───────────────────────────────────────────────────────────────

    public function addMember(FactionMember $member): void {
        $this->members[strtolower($member->getName())] = $member;
    }

    public function removeMember(string $name): void {
        unset($this->members[strtolower($name)]);
    }

    public function getMember(string $name): ?FactionMember {
        return $this->members[strtolower($name)] ?? null;
    }

    /** @return FactionMember[] */
    public function getMembers(): array { return $this->members; }

    public function getMemberCount(): int { return count($this->members); }

    public function hasMember(string $name): bool {
        return isset($this->members[strtolower($name)]);
    }

    public function getLeader(): ?FactionMember {
        foreach ($this->members as $m) {
            if ($m->isLeader()) return $m;
        }
        return null;
    }

    public function getTotalPower(): float {
        $total = 0.0;
        foreach ($this->members as $m) $total += $m->getPower();
        return $total;
    }

    public function getMaxPower(): float {
        return count($this->members) * 20.0;
    }

    // ─── Claims ────────────────────────────────────────────────────────────────

    public function addClaim(Claim $claim): void {
        $this->claims[$claim->getKey()] = $claim;
    }

    public function removeClaim(string $key): void {
        unset($this->claims[$key]);
    }

    public function getClaims(): array { return $this->claims; }

    public function getClaimCount(): int { return count($this->claims); }

    public function hasClaim(string $key): bool {
        return isset($this->claims[$key]);
    }

    // ─── Spawners (Geradores) ──────────────────────────────────────────────────

    public function addSpawner(string $type, int $x, int $y, int $z, string $world, int $count = 1): void {
        $key = "{$world}:{$x}:{$y}:{$z}";
        if (isset($this->spawners[$key])) {
            $this->spawners[$key]["count"] += $count;
        } else {
            $this->spawners[$key] = [
                "type"  => strtoupper($type),
                "x"     => $x,
                "y"     => $y,
                "z"     => $z,
                "world" => $world,
                "count" => $count
            ];
        }
    }

    public function removeSpawner(string $key): void {
        unset($this->spawners[$key]);
    }

    public function getSpawners(): array { return $this->spawners; }

    public function getSpawnerCount(): int {
        $total = 0;
        foreach ($this->spawners as $s) $total += $s["count"];
        return $total;
    }

    public function getSpawnerValue(): int {
        // Cada spawner vale 1 para o top (pode ser configurado)
        return $this->getSpawnerCount();
    }

    // ─── Convites ──────────────────────────────────────────────────────────────

    public function addInvite(string $playerName): void {
        $this->invites[strtolower($playerName)] = strtolower($playerName);
    }

    public function removeInvite(string $playerName): void {
        unset($this->invites[strtolower($playerName)]);
    }

    public function hasInvite(string $playerName): bool {
        return isset($this->invites[strtolower($playerName)]);
    }

    // ─── Fly ───────────────────────────────────────────────────────────────────

    public function addFlyPlayer(string $name): void   { $this->flyPlayers[strtolower($name)] = true; }
    public function removeFlyPlayer(string $name): void { unset($this->flyPlayers[strtolower($name)]); }
    public function hasFlyPlayer(string $name): bool    { return isset($this->flyPlayers[strtolower($name)]); }

    // ─── Explosões ────────────────────────────────────────────────────────────

    public function addExplosion(int $cX, int $cZ, string $world): void {
        $key = "{$world}:{$cX}:{$cZ}";
        $this->recentExplosions[$key] = time() + 300; // Alerta por 5 minutos
    }

    public function isChunkUnderAttack(int $cX, int $cZ, string $world): bool {
        $key = "{$world}:{$cX}:{$cZ}";
        if (isset($this->recentExplosions[$key])) {
            if (time() > $this->recentExplosions[$key]) {
                unset($this->recentExplosions[$key]);
                return false;
            }
            return true;
        }
        return false;
    }

    public function isUnderAttack(): bool {
        foreach ($this->recentExplosions as $key => $expiry) {
            if (time() < $expiry) return true;
        }
        return false;
    }

    // ─── Aliados ──────────────────────────────────────────────────────────────

    public function addAlly(string $factionName): void {
        $this->allies[strtolower($factionName)] = strtolower($factionName);
    }

    public function removeAlly(string $factionName): void {
        unset($this->allies[strtolower($factionName)]);
    }

    public function isAlly(string $factionName): bool {
        return isset($this->allies[strtolower($factionName)]);
    }

    public function getAllies(): array {
        return array_values($this->allies);
    }

    // ─── Serialização ──────────────────────────────────────────────────────────

    public function toArray(): array {
        $members = [];
        foreach ($this->members as $k => $m) $members[$k] = $m->toArray();

        $claims = [];
        foreach ($this->claims as $k => $c) $claims[$k] = $c->toArray();

        return [
            "name"        => $this->name,
            "description" => $this->description,
            "tag"         => $this->tag,
            "money"       => $this->money,
            "createdAt"   => $this->createdAt,
            "open"        => $this->open,
            "kills"       => $this->kills,
            "deaths"      => $this->deaths,
            "members"     => $members,
            "claims"      => $claims,
            "spawners"    => $this->spawners,
            "invites"     => array_values($this->invites),
            "allies"      => array_values($this->allies)
        ];
    }

    public static function fromArray(array $data): self {
        $f = new self($data["name"], $data["description"] ?? "", $data["tag"] ?? "");
        $f->money     = (float)($data["money"]     ?? 0);
        $f->createdAt = (int)  ($data["createdAt"] ?? time());
        $f->open      = (bool) ($data["open"]      ?? false);
        $f->kills     = (int)  ($data["kills"]     ?? 0);
        $f->deaths    = (int)  ($data["deaths"]    ?? 0);
        $f->spawners  = $data["spawners"] ?? [];
        $f->allies    = [];
        foreach ($data["allies"] ?? [] as $ally) {
            $f->allies[strtolower($ally)] = strtolower($ally);
        }

        foreach ($data["members"] ?? [] as $k => $mData) {
            $f->members[$k] = FactionMember::fromArray($mData);
        }
        foreach ($data["claims"] ?? [] as $k => $cData) {
            $f->claims[$k] = Claim::fromArray($cData);
        }
        foreach ($data["invites"] ?? [] as $inv) {
            $f->invites[strtolower($inv)] = strtolower($inv);
        }
        return $f;
    }
}
