<?php

declare(strict_types=1);

namespace zPlugins\Factions\Forms;

use pocketmine\player\Player;
use zPlugins\Factions\Data\Faction;
use zPlugins\Factions\Main;
use zPlugins\Factions\Manager\SpawnerManager;
use zPlugins\Factions\Utils\Rank;

class FormManager {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    // ─── Menu Principal /f ─────────────────────────────────────────────────────

    public function sendMainMenu(Player $player): void {
        $fm      = $this->plugin->getFactionManager();
        $faction = $fm->getPlayerFaction($player->getName());

        if ($faction === null) {
            $this->sendNoFactionMenu($player);
            return;
        }

        $member = $faction->getMember($player->getName());
        $rank   = $member ? $member->getRank() : Rank::MEMBER;

        $buttons = [
            ["text" => "§l§eℹ Info da Facção\n§r§7Ver informações"],
            ["text" => "§l§aMembros\n§r§7Gerenciar membros"],
            ["text" => "§l§bGeradores\n§r§7Spawners armazenados"],
            ["text" => "§l§dTop Facções\n§r§7Ranking geral"],
            ["text" => "§l§6Mapa\n§r§7Mapa de claims"],
            ["text" => "§l§cSair da Facção\n§r§7Deixar a facção"],
        ];

        if (Rank::canManage($rank)) {
            $buttons[] = ["text" => "§l§4Gerenciar\n§r§7Opções de liderança"];
        }

        $form = [
            "type"    => "form",
            "title"   => "§l§6zFactions §r§7- §e" . $faction->getName(),
            "content" => "§7Bem-vindo, §e" . $player->getName() . "§7!\n" .
                         "§7Facção: §e" . $faction->getName() . "\n" .
                         "§7Cargo: " . Rank::getName($rank) . "\n" .
                         "§7Membros: §f" . $faction->getMemberCount() . "\n" .
                         "§7Claims: §f" . $faction->getClaimCount() . "\n" .
                         "§7Spawners: §f" . number_format($faction->getSpawnerCount()),
            "buttons" => $buttons
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) use ($faction, $rank) {
            if ($data === null) return;
            switch ((int)$data) {
                case 0: $this->sendFactionInfo($p, $faction); break;
                case 1: $this->sendMembersMenu($p, $faction); break;
                case 2: $this->sendSpawnersMenu($p, $faction); break;
                case 3: $this->sendTopMenu($p); break;
                case 4: $this->plugin->getCommandHandler()->handleMap($p); break;
                case 5: $this->sendConfirmLeave($p, $faction); break;
                case 6:
                    if (Rank::canManage($rank)) $this->sendManageMenu($p, $faction);
                    break;
            }
        }, $form));
    }

    // ─── Menu sem Facção ───────────────────────────────────────────────────────

    public function sendNoFactionMenu(Player $player): void {
        $form = [
            "type"    => "form",
            "title"   => "§l§6zFactions",
            "content" => "§7Você não está em nenhuma facção.\n§7O que deseja fazer?",
            "buttons" => [
                ["text" => "§l§aCriar Facção\n§r§7Criar uma nova facção"],
                ["text" => "§l§eTop Facções\n§r§7Ver o ranking"],
                ["text" => "§l§7Fechar\n§r§7Fechar menu"],
            ]
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) {
            if ($data === null) return;
            switch ((int)$data) {
                case 0: $this->sendCreateFactionForm($p); break;
                case 1: $this->sendTopMenu($p); break;
            }
        }, $form));
    }

    // ─── Criar Facção ──────────────────────────────────────────────────────────

    public function sendCreateFactionForm(Player $player): void {
        $form = [
            "type"    => "custom_form",
            "title"   => "§l§aCriar Facção",
            "content" => [
                [
                    "type"    => "input",
                    "text"    => "§eTag da Facção (3-4 letras)",
                    "placeholder" => "Ex: WAR",
                    "default" => ""
                ],
                [
                    "type"    => "input",
                    "text"    => "§eNome Completo da Facção",
                    "placeholder" => "Ex: Warriors of Light",
                    "default" => ""
                ],
                [
                    "type"    => "input",
                    "text"    => "§eDescrição (opcional)",
                    "placeholder" => "Ex: A melhor facção do servidor!",
                    "default" => ""
                ]
            ]
        ];

        $player->sendForm(new CustomForm(function(Player $p, $data) {
            if ($data === null) return;
            $tag  = strtoupper(trim($data[0] ?? ""));
            $name = trim($data[1] ?? "");
            $desc = trim($data[2] ?? "");

            if (empty($tag) || strlen($tag) < 2 || strlen($tag) > 5) {
                $p->sendMessage("§cA TAG deve ter entre 2 e 5 caracteres!");
                return;
            }
            if (empty($name) || strlen($name) < 3 || strlen($name) > 20) {
                $p->sendMessage("§cO Nome deve ter entre 3 e 20 caracteres!");
                return;
            }

            $this->plugin->getCommandHandler()->handleCreate($p, $name, $desc, $tag);
        }, $form));
    }

    // ─── Info da Facção ────────────────────────────────────────────────────────

    public function sendFactionInfo(Player $player, Faction $faction): void {
        $leader  = $faction->getLeader();
        $sm      = $this->plugin->getSpawnerManager();
        $spawnerData = $sm->getSpawnersFormatted($faction);

        $content = "§6§l━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§eFacção: §f" . $faction->getName() . "\n";
        $content .= "§eTag: §f[" . $faction->getTag() . "]\n";
        $content .= "§eDescrição: §f" . ($faction->getDescription() ?: "Sem descrição") . "\n";
        $content .= "§eLíder: §f" . ($leader ? $leader->getName() : "N/A") . "\n";
        $content .= "§eMembros: §f" . $faction->getMemberCount() . "\n";
        $content .= "§eClaims: §f" . $faction->getClaimCount() . "\n";
        $content .= "§ePoder: §f" . number_format($faction->getTotalPower(), 1) . "/" . number_format($faction->getMaxPower(), 1) . "\n";
        $content .= "§eDinheiro: §f" . $this->plugin->getEconomyManager()->formatMoney($faction->getMoney()) . "\n";
        $content .= "§eSpawners: §f" . number_format($spawnerData["total"]) . "\n";
        $content .= "§eKills: §f" . $faction->getKills() . "\n";
        $content .= "§6§l━━━━━━━━━━━━━━━━━━━━";

        $form = [
            "type"    => "form",
            "title"   => "§l§6Info: " . $faction->getName(),
            "content" => $content,
            "buttons" => [
                ["text" => "§l§7Voltar"]
            ]
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) {
            $this->sendMainMenu($p);
        }, $form));
    }

    // ─── Menu de Membros ───────────────────────────────────────────────────────

    public function sendMembersMenu(Player $player, Faction $faction): void {
        $content = "§6§l━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§eFacção: §f" . $faction->getName() . "\n";
        $content .= "§eMembros: §f" . $faction->getMemberCount() . "\n\n";

        foreach ($faction->getMembers() as $member) {
            $online = \pocketmine\Server::getInstance()->getPlayerByName($member->getName()) !== null;
            $status = $online ? "§a●" : "§c●";
            $content .= $status . " " . Rank::getTag($member->getRank()) . " §f" . $member->getName() . "\n";
            $content .= "  §7Poder: §f" . number_format($member->getPower(), 1) . " §7| K/D: §f" . $member->getKills() . "/" . $member->getDeaths() . "\n";
        }

        $content .= "§6§l━━━━━━━━━━━━━━━━━━━━";

        $form = [
            "type"    => "form",
            "title"   => "§l§aMembros: " . $faction->getName(),
            "content" => $content,
            "buttons" => [
                ["text" => "§l§7Voltar"]
            ]
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) {
            $this->sendMainMenu($p);
        }, $form));
    }

    // ─── Menu de Geradores ─────────────────────────────────────────────────────

    public function sendSpawnersMenu(Player $player, Faction $faction): void {
        $sm          = $this->plugin->getSpawnerManager();
        $spawnerData = $sm->getSpawnersFormatted($faction);
        $total       = $spawnerData["total"];
        $showCoords  = $spawnerData["showCoords"];

        $content = "§6§l━━━━━━━━━━━━━━━━━━━━\n";
        $content .= "§eTotal de Spawners: §f" . number_format($total) . "\n";

        if ($showCoords) {
            $content .= "§c⚠ Acima de 10kk - Coordenadas visíveis!\n";
        }

        $content .= "\n§eGeradores armazenados:\n";

        if (empty($spawnerData["lines"])) {
            $content .= "§7Nenhum spawner armazenado.\n";
        } else {
            foreach ($spawnerData["lines"] as $line) {
                $content .= $line . "\n";
            }
        }

        $content .= "§6§l━━━━━━━━━━━━━━━━━━━━";

        $form = [
            "type"    => "form",
            "title"   => "§l§bGeradores: " . $faction->getName(),
            "content" => $content,
            "buttons" => [
                ["text" => "§l§7Voltar"]
            ]
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) {
            $this->sendMainMenu($p);
        }, $form));
    }

    // ─── Menu Top ──────────────────────────────────────────────────────────────

    public function sendTopMenu(Player $player): void {
        $form = [
            "type"    => "form",
            "title"   => "§l§dTop Facções",
            "content" => "§7Escolha o tipo de ranking:",
            "buttons" => [
                ["text" => "§l§bTop Spawners\n§r§7Por quantidade de geradores"],
                ["text" => "§l§eTop Dinheiro\n§r§7Por saldo da facção"],
                ["text" => "§l§cTop Kills\n§r§7Por número de kills"],
                ["text" => "§l§7Voltar"],
            ]
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) {
            if ($data === null) return;
            switch ((int)$data) {
                case 0: $this->sendTopSpawners($p); break;
                case 1: $this->sendTopMoney($p); break;
                case 2: $this->sendTopKills($p); break;
                case 3:
                    $fm = $this->plugin->getFactionManager();
                    if ($fm->getPlayerFaction($p->getName()) !== null) {
                        $this->sendMainMenu($p);
                    }
                    break;
            }
        }, $form));
    }

    // ─── Top Spawners ──────────────────────────────────────────────────────────

    public function sendTopSpawners(Player $player): void {
        $fm      = $this->plugin->getFactionManager();
        $top     = $fm->getTopBySpawners(10);
        $sm      = $this->plugin->getSpawnerManager();

        $content = "§6§l━━━━━━━━━━━━━━━━━━━━\n";
        $medals  = ["§6#1 §e", "§7#2 §f", "§c#3 §f", "§f#4 ", "§f#5 ", "§f#6 ", "§f#7 ", "§f#8 ", "§f#9 ", "§f#10 "];

        foreach ($top as $i => $faction) {
            $medal   = $medals[$i] ?? "§f#" . ($i + 1) . " ";
            $count   = $faction->getSpawnerCount();
            $content .= $medal . "§e" . $faction->getName() . " §7- §f" . SpawnerManager::formatNumber($count) . " spawners\n";
        }

        if (empty($top)) {
            $content .= "§7Nenhuma facção com spawners.\n";
        }

        $content .= "§6§l━━━━━━━━━━━━━━━━━━━━";

        $form = [
            "type"    => "form",
            "title"   => "§l§bTop Spawners",
            "content" => $content,
            "buttons" => [
                ["text" => "§l§7Voltar"]
            ]
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) {
            $this->sendTopMenu($p);
        }, $form));
    }

    // ─── Top Dinheiro ──────────────────────────────────────────────────────────

    public function sendTopMoney(Player $player): void {
        $fm      = $this->plugin->getFactionManager();
        $top     = $fm->getTopByMoney(10);
        $em      = $this->plugin->getEconomyManager();

        $content = "§6§l━━━━━━━━━━━━━━━━━━━━\n";
        $medals  = ["§6#1 §e", "§7#2 §f", "§c#3 §f", "§f#4 ", "§f#5 ", "§f#6 ", "§f#7 ", "§f#8 ", "§f#9 ", "§f#10 "];

        foreach ($top as $i => $faction) {
            $medal   = $medals[$i] ?? "§f#" . ($i + 1) . " ";
            $content .= $medal . "§e" . $faction->getName() . " §7- §f" . $em->formatMoney($faction->getMoney()) . "\n";
        }

        if (empty($top)) {
            $content .= "§7Nenhuma facção com dinheiro.\n";
        }

        $content .= "§6§l━━━━━━━━━━━━━━━━━━━━";

        $form = [
            "type"    => "form",
            "title"   => "§l§eTop Dinheiro",
            "content" => $content,
            "buttons" => [
                ["text" => "§l§7Voltar"]
            ]
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) {
            $this->sendTopMenu($p);
        }, $form));
    }

    // ─── Top Kills ─────────────────────────────────────────────────────────────

    public function sendTopKills(Player $player): void {
        $fm  = $this->plugin->getFactionManager();
        $top = $fm->getTopByKills(10);

        $content = "§6§l━━━━━━━━━━━━━━━━━━━━\n";
        $medals  = ["§6#1 §e", "§7#2 §f", "§c#3 §f", "§f#4 ", "§f#5 ", "§f#6 ", "§f#7 ", "§f#8 ", "§f#9 ", "§f#10 "];

        foreach ($top as $i => $faction) {
            $medal   = $medals[$i] ?? "§f#" . ($i + 1) . " ";
            $content .= $medal . "§e" . $faction->getName() . " §7- §f" . number_format($faction->getKills()) . " kills\n";
        }

        if (empty($top)) {
            $content .= "§7Nenhuma facção com kills.\n";
        }

        $content .= "§6§l━━━━━━━━━━━━━━━━━━━━";

        $form = [
            "type"    => "form",
            "title"   => "§l§cTop Kills",
            "content" => $content,
            "buttons" => [
                ["text" => "§l§7Voltar"]
            ]
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) {
            $this->sendTopMenu($p);
        }, $form));
    }

    // ─── Confirmar Saída ───────────────────────────────────────────────────────

    public function sendConfirmLeave(Player $player, Faction $faction): void {
        $member = $faction->getMember($player->getName());
        if ($member && $member->isLeader()) {
            $player->sendMessage("§cVocê é o Líder! Use §e/f disband §cpara dissolver a facção ou §e/f transfer §cpara transferir a liderança.");
            return;
        }

        $form = [
            "type"    => "modal",
            "title"   => "§l§cSair da Facção",
            "content" => "§cTem certeza que deseja sair da facção §e" . $faction->getName() . "§c?",
            "button1" => "§l§cSair",
            "button2" => "§l§aCancelar"
        ];

        $player->sendForm(new ModalForm(function(Player $p, $data) use ($faction) {
            if ($data === true) {
                $this->plugin->getCommandHandler()->handleLeave($p);
            } else {
                $this->sendMainMenu($p);
            }
        }, $form));
    }

    // ─── Menu Gerenciar (Líder/Co-Líder) ───────────────────────────────────────

    public function sendManageMenu(Player $player, Faction $faction): void {
        $member = $faction->getMember($player->getName());
        $rank   = $member ? $member->getRank() : Rank::MEMBER;

        $buttons = [
            ["text" => "§l§aConvidar Jogador\n§r§7Enviar convite"],
            ["text" => "§l§cExpulsar Membro\n§r§7Kick de membro"],
            ["text" => "§l§eReivindicar Chunk\n§r§7Claim do chunk atual"],
            ["text" => "§l§6Liberar Chunk\n§r§7Unclaim do chunk atual"],
            ["text" => "§l§bAuto-Claim\n§r§7Ativar/desativar auto-claim"],
            ["text" => "§l§dDepositar Dinheiro\n§r§7Depositar na facção"],
        ];

        if (Rank::isLeader($rank)) {
            $buttons[] = ["text" => "§l§4Dissolver Facção\n§r§7Deletar a facção"];
            $buttons[] = ["text" => "§l§5Promover Membro\n§r§7Mudar cargo de membro"];
        }

        $buttons[] = ["text" => "§l§7Voltar"];

        $form = [
            "type"    => "form",
            "title"   => "§l§4Gerenciar: " . $faction->getName(),
            "content" => "§7Opções de gerenciamento da facção.",
            "buttons" => $buttons
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) use ($faction, $rank, $buttons) {
            if ($data === null) return;
            $idx = (int)$data;
            switch ($idx) {
                case 0: $this->sendInviteForm($p, $faction); break;
                case 1: $this->sendKickMenu($p, $faction); break;
                case 2: $this->plugin->getCommandHandler()->handleClaim($p); break;
                case 3: $this->plugin->getCommandHandler()->handleUnclaim($p); break;
                case 4: $this->plugin->getCommandHandler()->handleAutoClaim($p); break;
                case 5: $this->sendDepositForm($p, $faction); break;
                case 6:
                    if (Rank::isLeader($rank)) {
                        $this->sendConfirmDisband($p, $faction);
                    } else {
                        $this->sendMainMenu($p);
                    }
                    break;
                case 7:
                    if (Rank::isLeader($rank)) {
                        $this->sendPromoteMenu($p, $faction);
                    } else {
                        $this->sendMainMenu($p);
                    }
                    break;
                default: $this->sendMainMenu($p); break;
            }
        }, $form));
    }

    // ─── Convidar Jogador ──────────────────────────────────────────────────────

    public function sendInviteForm(Player $player, Faction $faction): void {
        $form = [
            "type"    => "custom_form",
            "title"   => "§l§aConvidar Jogador",
            "content" => [
                [
                    "type"        => "input",
                    "text"        => "§eNome do jogador",
                    "placeholder" => "Ex: Steve",
                    "default"     => ""
                ]
            ]
        ];

        $player->sendForm(new CustomForm(function(Player $p, $data) use ($faction) {
            if ($data === null) return;
            $target = trim($data[0] ?? "");
            if (empty($target)) return;
            $this->plugin->getCommandHandler()->handleInvite($p, $target);
        }, $form));
    }

    // ─── Expulsar Membro ───────────────────────────────────────────────────────

    public function sendKickMenu(Player $player, Faction $faction): void {
        $members = [];
        foreach ($faction->getMembers() as $m) {
            if (strtolower($m->getName()) !== strtolower($player->getName())) {
                $members[] = $m->getName();
            }
        }

        if (empty($members)) {
            $player->sendMessage("§cNão há membros para expulsar.");
            $this->sendManageMenu($player, $faction);
            return;
        }

        $buttons = [];
        foreach ($members as $name) {
            $m = $faction->getMember($name);
            $buttons[] = ["text" => Rank::getTag($m ? $m->getRank() : 0) . " §f" . $name];
        }
        $buttons[] = ["text" => "§l§7Cancelar"];

        $form = [
            "type"    => "form",
            "title"   => "§l§cExpulsar Membro",
            "content" => "§7Selecione o membro para expulsar:",
            "buttons" => $buttons
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) use ($faction, $members) {
            if ($data === null) return;
            $idx = (int)$data;
            if ($idx < count($members)) {
                $this->plugin->getCommandHandler()->handleKick($p, $members[$idx]);
            } else {
                $this->sendManageMenu($p, $faction);
            }
        }, $form));
    }

    // ─── Depositar Dinheiro ────────────────────────────────────────────────────

    public function sendDepositForm(Player $player, Faction $faction): void {
        $em = $this->plugin->getEconomyManager();
        $balance = $em->getMoney($player);

        $form = [
            "type"    => "custom_form",
            "title"   => "§l§dDepositar Dinheiro",
            "content" => [
                [
                    "type"        => "input",
                    "text"        => "§eSeu saldo: §f" . $em->formatMoney($balance) . "\n§eQuantia a depositar:",
                    "placeholder" => "Ex: 1000",
                    "default"     => ""
                ]
            ]
        ];

        $player->sendForm(new CustomForm(function(Player $p, $data) use ($faction) {
            if ($data === null) return;
            $amount = (float)($data[0] ?? 0);
            if ($amount <= 0) {
                $p->sendMessage("§cValor inválido!");
                return;
            }
            $this->plugin->getCommandHandler()->handleDeposit($p, $amount);
        }, $form));
    }

    // ─── Confirmar Dissolução ──────────────────────────────────────────────────

    public function sendConfirmDisband(Player $player, Faction $faction): void {
        $form = [
            "type"    => "modal",
            "title"   => "§l§4Dissolver Facção",
            "content" => "§cTem certeza que deseja DISSOLVER a facção §e" . $faction->getName() . "§c?\n§c§lEssa ação é IRREVERSÍVEL!",
            "button1" => "§l§4Dissolver",
            "button2" => "§l§aCancelar"
        ];

        $player->sendForm(new ModalForm(function(Player $p, $data) use ($faction) {
            if ($data === true) {
                $this->plugin->getCommandHandler()->handleDisband($p);
            } else {
                $this->sendManageMenu($p, $faction);
            }
        }, $form));
    }

    // ─── Promover Membro ───────────────────────────────────────────────────────

    public function sendPromoteMenu(Player $player, Faction $faction): void {
        $members = [];
        foreach ($faction->getMembers() as $m) {
            if (!$m->isLeader()) $members[] = $m;
        }

        if (empty($members)) {
            $player->sendMessage("§cNão há membros para promover.");
            return;
        }

        $buttons = [];
        foreach ($members as $m) {
            $buttons[] = ["text" => Rank::getTag($m->getRank()) . " §f" . $m->getName()];
        }
        $buttons[] = ["text" => "§l§7Cancelar"];

        $form = [
            "type"    => "form",
            "title"   => "§l§5Promover Membro",
            "content" => "§7Selecione o membro para promover/rebaixar:",
            "buttons" => $buttons
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) use ($faction, $members) {
            if ($data === null) return;
            $idx = (int)$data;
            if ($idx < count($members)) {
                $target = $members[$idx];
                $this->sendRankSelectMenu($p, $faction, $target->getName());
            } else {
                $this->sendManageMenu($p, $faction);
            }
        }, $form));
    }

    public function sendRankSelectMenu(Player $player, Faction $faction, string $targetName): void {
        $form = [
            "type"    => "form",
            "title"   => "§l§5Cargo: §e" . $targetName,
            "content" => "§7Selecione o novo cargo para §e" . $targetName . "§7:",
            "buttons" => [
                ["text" => "§7Membro"],
                ["text" => "§aOficial"],
                ["text" => "§bCo-Líder"],
                ["text" => "§7Cancelar"],
            ]
        ];

        $player->sendForm(new SimpleForm(function(Player $p, $data) use ($faction, $targetName) {
            if ($data === null) return;
            $ranks = [Rank::MEMBER, Rank::OFFICER, Rank::COLIDER];
            $idx   = (int)$data;
            if ($idx < count($ranks)) {
                $this->plugin->getCommandHandler()->handleSetRank($p, $targetName, $ranks[$idx]);
            }
            $this->sendManageMenu($p, $faction);
        }, $form));
    }
}
