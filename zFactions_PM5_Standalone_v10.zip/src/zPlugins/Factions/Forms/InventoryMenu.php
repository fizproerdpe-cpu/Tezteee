<?php

declare(strict_types=1);

namespace zPlugins\Factions\Forms;

use muqsit\invmenu\InvMenu;
use muqsit\invmenu\transaction\InvMenuTransaction;
use muqsit\invmenu\transaction\InvMenuTransactionResult;
use pocketmine\item\ItemFactory;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use zPlugins\Factions\Data\Faction;
use zPlugins\Factions\Main;
use zPlugins\Factions\Utils\Rank;

class InventoryMenu {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    /**
     * Abre o menu de Geradores (InvMenu)
     */
    public function openSpawnersMenu(Player $player, Faction $faction): void {
        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        $menu->setName("§l§8Geradores: " . $faction->getName());

        $member = $faction->getMember($player->getName());
        $canManage = $member !== null && $member->isCoLeader();

        $inventory = $menu->getInventory();
        $spawners = $faction->getSpawners();

        $slot = 0;
        foreach ($spawners as $key => $data) {
            if ($slot >= 27) break;

            $item = VanillaItems::MONSTER_SPAWNER();
            $item->setCustomName("§l§eGerador de " . ucfirst(strtolower($data["type"])));
            $lore = [
                "§r§7Quantidade: §f" . number_format($data["count"]),
                "§r§7Localização:",
                "§r§7- X: §f" . $data["x"],
                "§r§7- Y: §f" . $data["y"],
                "§r§7- Z: §f" . $data["z"],
                "§r§7- Mundo: §f" . $data["world"],
                "",
            ];

            if ($canManage) {
                $lore[] = "§r§eClique para gerenciar";
            } else {
                $lore[] = "§r§cApenas Colíder pode gerenciar";
            }

            $item->setLore($lore);
            $inventory->setItem($slot++, $item);
        }

        // Preencher vazios com vidro cinza
        for ($i = 0; $i < 27; $i++) {
            if ($inventory->getItem($i)->isNull()) {
                $glass = VanillaItems::AIR(); // Placeholder ou vidro se preferir
                // $inventory->setItem($i, $glass);
            }
        }

        $menu->setListener(function(InvMenuTransaction $transaction) use ($canManage, $player): InvMenuTransactionResult {
            if (!$canManage) {
                $player->sendMessage("§cApenas o Colíder ou Líder pode mexer nos geradores!");
                return $transaction->discard();
            }
            // Lógica de retirada poderia ser implementada aqui
            return $transaction->discard();
        });

        $menu->send($player);
    }
}
