<?php

declare(strict_types=1);

namespace zPlugins\Factions\Forms;

use Closure;
use pocketmine\form\Form;
use pocketmine\player\Player;

class CustomForm implements Form {

    private Closure $callable;
    private array   $data;

    public function __construct(Closure $callable, array $data) {
        $this->callable = $callable;
        $this->data     = $data;
    }

    public function handleResponse(Player $player, mixed $data): void {
        ($this->callable)($player, $data);
    }

    public function jsonSerialize(): array {
        return $this->data;
    }
}
