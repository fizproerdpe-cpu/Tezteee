<?php

declare(strict_types=1);

namespace zPlugins\Factions\Listeners;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityExplodeEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\Player;
use pocketmine\block\MonsterSpawner;
use zPlugins\Factions\Main;

class EventListener implements Listener {

    private Main $plugin;

    /** @var array<string, int> player => timestamp do último combate */
    private array $inCombat = [];

    /** @var array<string, int> player => timestamp da última regeneração de poder */
    private array $lastPowerRegen = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onJoin(PlayerJoinEvent $event): void {
        $this->lastPowerRegen[strtolower($event->getPlayer()->getName())] = time();
    }

    public function onQuit(PlayerQuitEvent $event): void {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());

        // Combat Log: Se sair em combate, perde poder
        if (isset($this->inCombat[$name])) {
            if (time() < $this->inCombat[$name]) {
                $fm = $this->plugin->getFactionManager();
                $faction = $fm->getPlayerFaction($player->getName());
                if ($faction !== null) {
                    $member = $faction->getMember($player->getName());
                    if ($member) {
                        $member->reducePower(2.0); // Perde 2 de poder por sair em combate
                        $this->plugin->getServer()->broadcastMessage("§c[CombatLog] §e" . $player->getName() . " §csaiu em combate e perdeu poder!");
                    }
                }
            }
            unset($this->inCombat[$name]);
        }

        $this->plugin->getClaimManager()->clearPlayer($player->getName());
        $this->plugin->getFlyManager()->clearPlayer($player->getName());
        unset($this->lastPowerRegen[$name]);
    }

    public function onMove(PlayerMoveEvent $event): void {
        $player = $event->getPlayer();
        $name = strtolower($player->getName());
        $this->plugin->getClaimManager()->checkChunkChange($player, $player->getPosition());

        // Regeneração de poder (1 por hora)
        if (isset($this->lastPowerRegen[$name])) {
            if (time() - $this->lastPowerRegen[$name] >= 3600) {
                $fm = $this->plugin->getFactionManager();
                $faction = $fm->getPlayerFaction($player->getName());
                if ($faction !== null) {
                    $member = $faction->getMember($player->getName());
                    if ($member && $member->getPower() < 10) {
                        $member->addPower(1.0);
                        $player->sendMessage("§a[Poder] §fVocê ganhou §e1 §fde poder por ficar 1 hora online!");
                    }
                }
                $this->lastPowerRegen[$name] = time();
            }
        }
    }

    public function onBreak(BlockBreakEvent $event): void {
        $player = $event->getPlayer();
        $block  = $event->getBlock();
        $pos    = $block->getPosition();
        $dist   = sqrt(pow($pos->getX(), 2) + pow($pos->getZ(), 2));

        // Proteção total do Spawn (0-100 blocos)
        if ($dist <= 100 && !$player->hasPermission("zfactions.admin")) {
            $event->cancel();
            $player->sendTip("§cÁrea do Spawn Protegida!");
            return;
        }
        
        if (!$this->plugin->getClaimManager()->canBuild($player, $block->getPosition())) {
            $event->cancel();
            $player->sendTip("§cVocê não tem permissão aqui!");
            return;
        }

        // Se for spawner
        if ($block instanceof MonsterSpawner) {
            $faction = $this->plugin->getFactionManager()->getClaimAt(
                $block->getPosition()->getWorld()->getFolderName(),
                $block->getPosition()->getFloorX() >> 4,
                $block->getPosition()->getFloorZ() >> 4
            );
            if ($faction !== null) {
                $this->plugin->getSpawnerManager()->removeSpawner(
                    $faction,
                    $block->getPosition()->getWorld()->getFolderName(),
                    $block->getPosition()->getFloorX(),
                    $block->getPosition()->getFloorY(),
                    $block->getPosition()->getFloorZ()
                );
            }
        }
    }

    public function onPlace(BlockPlaceEvent $event): void {
        $player = $event->getPlayer();
        $block  = $event->getBlock();
        $pos    = $block->getPosition();
        $dist   = sqrt(pow($pos->getX(), 2) + pow($pos->getZ(), 2));

        // Proteção total do Spawn (0-100 blocos)
        if ($dist <= 100 && !$player->hasPermission("zfactions.admin")) {
            $event->cancel();
            $player->sendTip("§cÁrea do Spawn Protegida!");
            return;
        }

        if (!$this->plugin->getClaimManager()->canBuild($player, $block->getPosition())) {
            $event->cancel();
            $player->sendTip("§cVocê não tem permissão aqui!");
            return;
        }

        // Se for spawner
        if ($block instanceof MonsterSpawner) {
            $pos = $block->getPosition();
            $world = $pos->getWorld();
            $type = $this->plugin->getSpawnerManager()->getSpawnerTypeFromBlock($world, $pos);

            // Lógica de Slime Spawner
            if ($type !== null && str_contains(strtolower($type), "slime")) {
                $cX = $pos->getFloorX() >> 4;
                $cZ = $pos->getFloorZ() >> 4;
                if (!$this->plugin->getSpawnerManager()->isSlimeChunk($cX, $cZ, (int)$world->getSeed())) {
                    $event->cancel();
                    $player->sendMessage("§c§l⚠ ERRO: §r§cSlimes só podem ser gerados em Slime Chunks!");
                    $player->sendMessage("§7Dica: Use /chunk para encontrar uma Slime Chunk (partículas verdes).");
                    return;
                }
            }

            $faction = $this->plugin->getFactionManager()->getPlayerFaction($player->getName());
            if ($faction !== null) {
                $this->plugin->getSpawnerManager()->registerSpawner(
                    $faction,
                    $type ?? "ZOMBIE",
                    $pos->getFloorX(),
                    $pos->getFloorY(),
                    $pos->getFloorZ(),
                    $world->getFolderName()
                );
            }
        }
    }

    public function onDamage(EntityDamageEvent $event): void {
        $entity = $event->getEntity();
        if ($entity instanceof Player) {
            $pos = $entity->getPosition();
            $dist = sqrt(pow($pos->getX(), 2) + pow($pos->getZ(), 2));

            // Sem PVP no Spawn Protegido (0-100 blocos)
            if ($dist <= 100) {
                $event->cancel();
                return;
            }

            if ($event instanceof EntityDamageByEntityEvent) {
                $damager = $event->getDamager();
                if ($damager instanceof Player) {
                    $fm = $this->plugin->getFactionManager();
                    $f1 = $fm->getPlayerFaction($entity->getName());
                    $f2 = $fm->getPlayerFaction($damager->getName());

                    // PvP entre membros da mesma facção
                    if ($f1 !== null && $f2 !== null && strtolower($f1->getName()) === strtolower($f2->getName())) {
                        $event->cancel();
                        $damager->sendTip("§cVocê não pode bater em membros da sua facção!");
                        return;
                    }

                    // Marcar combate (15 segundos)
                    $this->inCombat[strtolower($entity->getName())] = time() + 15;
                    $this->inCombat[strtolower($damager->getName())] = time() + 15;
                }
            }
        }
    }

    public function onDeath(PlayerDeathEvent $event): void {
        $player = $event->getPlayer();
        $fm = $this->plugin->getFactionManager();
        $faction = $fm->getPlayerFaction($player->getName());
        
        if ($faction !== null) {
            $faction->addDeath();
            $member = $faction->getMember($player->getName());
            if ($member) $member->addDeath();
            
            $cause = $player->getLastDamageCause();
            if ($cause instanceof EntityDamageByEntityEvent) {
                $killer = $cause->getDamager();
                if ($killer instanceof Player) {
                    $kFaction = $fm->getPlayerFaction($killer->getName());
                    if ($kFaction !== null) {
                        $kFaction->addKill();
                        $kMember = $kFaction->getMember($killer->getName());
                        if ($kMember) $kMember->addKill();
                    }
                }
            }
        }
    }

    public function onExplode(EntityExplodeEvent $event): void {
        $pos = $event->getPosition();
        $world = $pos->getWorld()->getFolderName();
        $cX = $pos->getFloorX() >> 4;
        $cZ = $pos->getFloorZ() >> 4;

        $fm = $this->plugin->getFactionManager();
        $faction = $fm->getClaimAt($world, $cX, $cZ);

        if ($faction !== null) {
            $faction->addExplosion($cX, $cZ, $world);
            
            foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
                if ($faction->hasMember($player->getName())) {
                    $player->sendMessage("§c§l⚠ ALERTA: §r§cFacção sob ataque no chunk §e({$cX}, {$cZ})§c!");
                    $player->sendTitle("§c§lSOB ATAQUE!", "§7Verifique o /f mapa", 10, 40, 10);
                }
            }
        }
    }
}
