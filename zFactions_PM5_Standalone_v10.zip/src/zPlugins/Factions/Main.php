<?php

declare(strict_types=1);

namespace zPlugins\Factions;

use pocketmine\plugin\PluginBase;
use pocketmine\utils\SingletonTrait;
use zPlugins\Factions\Manager\FactionManager;
use zPlugins\Factions\Manager\SpawnerManager;
use zPlugins\Factions\Manager\EconomyManager;
use zPlugins\Factions\Manager\ClaimManager;
use zPlugins\Factions\Manager\FlyManager;
use zPlugins\Factions\Forms\FormManager;
use zPlugins\Factions\Commands\CommandHandler;
use zPlugins\Factions\Listeners\EventListener;

class Main extends PluginBase {
    use SingletonTrait;

    private FactionManager $factionManager;
    private SpawnerManager $spawnerManager;
    private EconomyManager $economyManager;
    private ClaimManager   $claimManager;
    private FlyManager     $flyManager;
    private FormManager    $formManager;
    private CommandHandler $commandHandler;
    private \zPlugins\Factions\Tasks\VisualChunkTask $visualChunkTask;

    protected function onEnable(): void {
        self::setInstance($this);
        $this->saveDefaultConfig();

        // Inicializar InvMenu (Standalone Injetado)
        if (!\muqsit\invmenu\InvMenuHandler::isRegistered()) {
            \muqsit\invmenu\InvMenuHandler::register($this);
        }

        // Inicializar Managers
        $this->factionManager = new FactionManager($this);
        $this->spawnerManager = new SpawnerManager($this);
        $this->economyManager = new EconomyManager($this);
        $this->claimManager   = new ClaimManager($this);
        $this->flyManager     = new FlyManager($this);
        $this->formManager    = new FormManager($this);
        $this->commandHandler = new CommandHandler($this);

        // Registrar Eventos
        $this->getServer()->getPluginManager()->registerEvents(new EventListener($this), $this);
        $this->getScheduler()->scheduleRepeatingTask(new \zPlugins\Factions\Tasks\FlyTask($this), 20);
        
        $this->visualChunkTask = new \zPlugins\Factions\Tasks\VisualChunkTask();
        $this->getScheduler()->scheduleRepeatingTask($this->visualChunkTask, 10);

        $this->getLogger()->info("§a[zFactions] Plugin ativado com sucesso! (API 5.x)");
    }

    public function getVisualChunkTask(): \zPlugins\Factions\Tasks\VisualChunkTask { return $this->visualChunkTask; }

    protected function onDisable(): void {
        if (isset($this->factionManager)) {
            $this->factionManager->saveAll();
        }
    }

    public function getFactionManager(): FactionManager { return $this->factionManager; }
    public function getSpawnerManager(): SpawnerManager { return $this->spawnerManager; }
    public function getEconomyManager(): EconomyManager { return $this->economyManager; }
    public function getClaimManager(): ClaimManager   { return $this->claimManager; }
    public function getFlyManager(): FlyManager       { return $this->flyManager; }
    public function getFormManager(): FormManager     { return $this->formManager; }
    public function getCommandHandler(): CommandHandler { return $this->commandHandler; }
}
