<?php

declare(strict_types=1);

namespace zPlugins\Factions\Commands;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use zPlugins\Factions\Data\FactionMember;
use zPlugins\Factions\Main;
use zPlugins\Factions\Utils\Rank;

class CommandHandler {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->registerCommands();
    }

    private function registerCommands(): void {
        $map = $this->plugin->getServer()->getCommandMap();
        
        // Comando /f
        $fCommand = new class("f", "Comando principal de Factions", "/f [subcomando]", ["faction", "factions"]) extends Command {
            public function execute(CommandSender $sender, string $commandLabel, array $args): void {
                if (!$sender instanceof Player) return;
                Main::getInstance()->getCommandHandler()->handleF($sender, $args);
            }
        };
        $map->register("zFactions", $fCommand);

        // Comando /ffly
        $flyCommand = new class("ffly", "Ativa/desativa voo na facção", "/ffly", ["f fly"]) extends Command {
            public function execute(CommandSender $sender, string $commandLabel, array $args): void {
                if (!$sender instanceof Player) return;
                Main::getInstance()->getFlyManager()->toggleFly($sender);
            }
        };
        $map->register("zFactions", $flyCommand);

        // Comando /chunk
        $chunkCommand = new class("chunk", "Mostra as bordas do chunk atual", "/chunk", []) extends Command {
            public function execute(CommandSender $sender, string $commandLabel, array $args): void {
                if (!$sender instanceof Player) return;
                $task = Main::getInstance()->getVisualChunkTask();
                if ($task->isViewing($sender)) {
                    $task->removePlayer($sender);
                    $sender->sendMessage("§cVisualização de chunk desativada!");
                } else {
                    $task->addPlayer($sender);
                    $sender->sendMessage("§aVisualização de chunk ativada! Bordas marcadas com fumaça.");
                }
            }
        };
        $map->register("zFactions", $chunkCommand);
    }

    public function handleF(Player $player, array $args): void {
        if (empty($args)) {
            $this->plugin->getFormManager()->sendMainMenu($player);
            return;
        }

        $sub = strtolower($args[0]);
        switch ($sub) {
            case "create":
                if (isset($args[1])) {
                    $this->handleCreate($player, $args[1], $args[2] ?? "", $args[3] ?? "");
                } else {
                    $this->plugin->getFormManager()->sendCreateFactionForm($player);
                }
                break;
            case "disband":
                $this->handleDisband($player);
                break;
            case "claim":
                $this->handleClaim($player);
                break;
            case "unclaim":
                $this->handleUnclaim($player);
                break;
            case "autoclaim":
                $this->handleAutoClaim($player);
                break;
            case "map":
            case "mapa":
                $this->handleMap($player);
                break;
            case "top":
                $this->plugin->getFormManager()->sendTopMenu($player);
                break;
            case "invite":
                if (isset($args[1])) $this->handleInvite($player, $args[1]);
                break;
            case "kick":
                if (isset($args[1])) $this->handleKick($player, $args[1]);
                break;
            case "leave":
                $this->handleLeave($player);
                break;
            default:
                $player->sendMessage("§cSubcomando desconhecido. Use /f para abrir o menu.");
                break;
        }
    }

    public function handleCreate(Player $player, string $name, string $desc = "", string $tag = ""): void {
        $fm = $this->plugin->getFactionManager();
        if ($fm->isInFaction($player->getName())) {
            $player->sendMessage("§cVocê já está em uma facção!");
            return;
        }
        if ($fm->factionExists($name)) {
            $player->sendMessage("§cJá existe uma facção com esse nome!");
            return;
        }

        $leader = new FactionMember($player->getName(), $player->getUniqueId()->toString(), Rank::LEADER);
        if ($fm->createFaction($name, $leader)) {
            $faction = $fm->getFaction($name);
            if ($desc !== "") $faction->setDescription($desc);
            if ($tag !== "") $faction->setTag($tag);
            $player->sendMessage("§aFacção §e$name §acriada com sucesso!");
        }
    }

    public function handleDisband(Player $player): void {
        $fm = $this->plugin->getFactionManager();
        $faction = $fm->getPlayerFaction($player->getName());
        if ($faction === null) {
            $player->sendMessage("§cVocê não está em uma facção!");
            return;
        }
        $member = $faction->getMember($player->getName());
        if (!$member->isLeader()) {
            $player->sendMessage("§cApenas o Líder pode dissolver a facção!");
            return;
        }
        $name = $faction->getName();
        if ($fm->disbandFaction($name)) {
            $player->sendMessage("§aFacção §e$name §adissolvida!");
        }
    }

    public function handleClaim(Player $player): void {
        $fm = $this->plugin->getFactionManager();
        $faction = $fm->getPlayerFaction($player->getName());
        if ($faction === null) {
            $player->sendMessage("§cVocê não está em uma facção!");
            return;
        }
        $member = $faction->getMember($player->getName());
        if (!$member->canManage()) {
            $player->sendMessage("§cApenas Colíder ou Líder podem reivindicar terras!");
            return;
        }
        $pos = $player->getPosition();
        $spawnDist = sqrt(pow($pos->getX(), 2) + pow($pos->getZ(), 2));
        
        if ($spawnDist <= 300) {
            $player->sendMessage("§cVocê precisa estar a mais de 300 blocos do Spawn para dar claim!");
            return;
        }

        if ($fm->claimChunk($faction, $pos->getWorld()->getFolderName(), $pos->getFloorX() >> 4, $pos->getFloorZ() >> 4)) {
            $player->sendMessage("§aTerritório reivindicado com sucesso!");
        } else {
            $player->sendMessage("§cEste território já pertence a alguém!");
        }
    }

    public function handleUnclaim(Player $player): void {
        $fm = $this->plugin->getFactionManager();
        $faction = $fm->getPlayerFaction($player->getName());
        if ($faction === null) return;
        $member = $faction->getMember($player->getName());
        if (!$member->canManage()) return;
        
        $pos = $player->getPosition();
        if ($fm->unclaimChunk($faction, $pos->getWorld()->getFolderName(), $pos->getFloorX() >> 4, $pos->getFloorZ() >> 4)) {
            $player->sendMessage("§aTerritório liberado!");
        } else {
            $player->sendMessage("§cEste território não pertence à sua facção!");
        }
    }

    public function handleAutoClaim(Player $player): void {
        $status = $this->plugin->getClaimManager()->toggleAutoClaim($player->getName());
        $player->sendMessage($status ? "§aAuto-claim ativado!" : "§cAuto-claim desativado!");
    }

    public function handleMap(Player $player): void {
        $pos = $player->getPosition();
        $world = $pos->getWorld()->getFolderName();
        $cX = $pos->getFloorX() >> 4;
        $cZ = $pos->getFloorZ() >> 4;
        $fm = $this->plugin->getFactionManager();
        $playerFaction = $fm->getPlayerFaction($player->getName());

        $map = "§6--- §eMapa de Factions §6---\n";
        for ($z = $cZ - 4; $z <= $cZ + 4; $z++) {
            $line = "";
            for ($x = $cX - 4; $x <= $cX + 4; $x++) {
                if ($x === $cX && $z === $cZ) {
                    $line .= "§b+";
                    continue;
                }
                $f = $fm->getClaimAt($world, $x, $z);
                if ($f === null) {
                    $line .= "§7-";
                } else {
                    if ($f->isChunkUnderAttack($x, $z, $world)) {
                        $line .= "§c§lX§r";
                    } elseif ($playerFaction !== null) {
                        if (strtolower($f->getName()) === strtolower($playerFaction->getName())) {
                            $line .= "§a#"; // Sua facção (Verde)
                        } elseif ($playerFaction->isAlly($f->getName())) {
                            $line .= "§e#"; // Aliados (Amarelo)
                        } else {
                            $line .= "§c#"; // Inimigos (Vermelho)
                        }
                    } else {
                        $line .= "§c#"; // Sem facção vê tudo vermelho
                    }
                }
            }
            $map .= "§r $line\n";
        }
        $player->sendMessage($map);
    }

    public function handleInvite(Player $player, string $targetName): void {
        $fm = $this->plugin->getFactionManager();
        $faction = $fm->getPlayerFaction($player->getName());
        if ($faction === null) return;
        if (!$faction->getMember($player->getName())->canManage()) return;

        $target = $this->plugin->getServer()->getPlayerByPrefix($targetName);
        if ($target === null) {
            $player->sendMessage("§cJogador não encontrado!");
            return;
        }
        $faction->addInvite($target->getName());
        $player->sendMessage("§aJogador §e" . $target->getName() . " §aconvidado!");
        $target->sendMessage("§aVocê foi convidado para a facção §e" . $faction->getName() . "§a! Use §e/f join " . $faction->getName() . " §apara entrar.");
    }

    public function handleKick(Player $player, string $targetName): void {
        $fm = $this->plugin->getFactionManager();
        $faction = $fm->getPlayerFaction($player->getName());
        if ($faction === null) return;
        if (!$faction->getMember($player->getName())->canManage()) return;

        if ($faction->hasMember($targetName)) {
            $targetMember = $faction->getMember($targetName);
            if ($targetMember->getRank() >= $faction->getMember($player->getName())->getRank()) {
                $player->sendMessage("§cVocê não pode expulsar alguém com cargo igual ou superior!");
                return;
            }
            $fm->leaveFaction($targetName);
            $player->sendMessage("§aJogador §e$targetName §aexpulso!");
        }
    }

    public function handleLeave(Player $player): void {
        $fm = $this->plugin->getFactionManager();
        $faction = $fm->getPlayerFaction($player->getName());
        if ($faction === null) return;
        if ($faction->getMember($player->getName())->isLeader()) {
            $player->sendMessage("§cO líder não pode sair! Dissolva ou transfira a facção.");
            return;
        }
        $fm->leaveFaction($player->getName());
        $player->sendMessage("§aVocê saiu da facção!");
    }

    public function handleDeposit(Player $player, float $amount): void {
        $em = $this->plugin->getEconomyManager();
        if ($em->reduceMoney($player, $amount)) {
            $faction = $this->plugin->getFactionManager()->getPlayerFaction($player->getName());
            if ($faction !== null) {
                $faction->addMoney($amount);
                $player->sendMessage("§aVocê depositou §e" . $em->formatMoney($amount) . " §ana facção!");
            }
        } else {
            $player->sendMessage("§cVocê não tem dinheiro suficiente!");
        }
    }

    public function handleSetRank(Player $player, string $targetName, int $newRank): void {
        $faction = $this->plugin->getFactionManager()->getPlayerFaction($player->getName());
        if ($faction === null || !$faction->getMember($player->getName())->isLeader()) return;
        
        $target = $faction->getMember($targetName);
        if ($target !== null) {
            $target->setRank($newRank);
            $player->sendMessage("§aCargo de §e$targetName §aatualizado para " . Rank::getName($newRank));
        }
    }
}
