<?php

declare(strict_types=1);

namespace zPlugins\Factions\Manager;

use pocketmine\utils\Config;
use zPlugins\Factions\Data\Claim;
use zPlugins\Factions\Data\Faction;
use zPlugins\Factions\Data\FactionMember;
use zPlugins\Factions\Main;
use zPlugins\Factions\Utils\Rank;

class FactionManager {

    private Main $plugin;

    /** @var Faction[] */
    private array $factions = [];

    /** @var array<string, string> playerName => factionName */
    private array $playerFaction = [];

    private string $dataPath;

    public function __construct(Main $plugin) {
        $this->plugin   = $plugin;
        $this->dataPath = $plugin->getDataFolder() . "factions/";
        @mkdir($this->dataPath, 0777, true);
        $this->loadAll();
    }

    // ─── CRUD de Facções ───────────────────────────────────────────────────────

    public function createFaction(string $name, FactionMember $leader): bool {
        if ($this->factionExists($name)) return false;
        $faction = new Faction($name);
        $faction->addMember($leader);
        $this->factions[strtolower($name)] = $faction;
        $this->playerFaction[strtolower($leader->getName())] = strtolower($name);
        $this->saveFaction($faction);
        return true;
    }

    public function disbandFaction(string $name): bool {
        $key = strtolower($name);
        if (!isset($this->factions[$key])) return false;
        $faction = $this->factions[$key];

        // Remove todos os membros do índice
        foreach ($faction->getMembers() as $m) {
            unset($this->playerFaction[strtolower($m->getName())]);
        }

        // Remove arquivo
        $file = $this->dataPath . $key . ".json";
        if (file_exists($file)) @unlink($file);

        unset($this->factions[$key]);
        return true;
    }

    public function getFaction(string $name): ?Faction {
        return $this->factions[strtolower($name)] ?? null;
    }

    public function getPlayerFaction(string $playerName): ?Faction {
        $key = $this->playerFaction[strtolower($playerName)] ?? null;
        if ($key === null) return null;
        return $this->factions[$key] ?? null;
    }

    public function factionExists(string $name): bool {
        return isset($this->factions[strtolower($name)]);
    }

    public function isInFaction(string $playerName): bool {
        return isset($this->playerFaction[strtolower($playerName)]);
    }

    /** @return Faction[] */
    public function getAllFactions(): array {
        return $this->factions;
    }

    // ─── Membros ───────────────────────────────────────────────────────────────

    public function joinFaction(Faction $faction, FactionMember $member): void {
        $faction->addMember($member);
        $this->playerFaction[strtolower($member->getName())] = strtolower($faction->getName());
        $this->saveFaction($faction);
    }

    public function leaveFaction(string $playerName): bool {
        $faction = $this->getPlayerFaction($playerName);
        if ($faction === null) return false;
        $faction->removeMember($playerName);
        unset($this->playerFaction[strtolower($playerName)]);
        $this->saveFaction($faction);
        return true;
    }

    // ─── Claims ────────────────────────────────────────────────────────────────

    public function getClaimAt(string $world, int $chunkX, int $chunkZ): ?Faction {
        $key = Claim::makeKey($world, $chunkX, $chunkZ);
        foreach ($this->factions as $faction) {
            if ($faction->hasClaim($key)) return $faction;
        }
        return null;
    }

    public function claimChunk(Faction $faction, string $world, int $chunkX, int $chunkZ): bool {
        $key = Claim::makeKey($world, $chunkX, $chunkZ);
        
        // Verifica se já está reivindicado por outra facção
        foreach ($this->factions as $otherFaction) {
            if ($otherFaction->hasClaim($key)) {
                // Lógica de Overclaim: Se o poder da facção dona for menor que seus claims
                // Exemplo: Se tem 10 claims e 9 de poder, pode perder claims.
                if ($otherFaction->getTotalPower() < $otherFaction->getClaimCount()) {
                    // Remove o claim da facção antiga
                    $otherFaction->removeClaim($key);
                    $this->saveFaction($otherFaction);
                    
                    // Adiciona para a nova facção
                    $claim = new Claim($chunkX, $chunkZ, $world, $faction->getName());
                    $faction->addClaim($claim);
                    $this->saveFaction($faction);
                    return true;
                }
                return false; // Ainda tem poder suficiente
            }
        }
        
        // Terreno livre
        $claim = new Claim($chunkX, $chunkZ, $world, $faction->getName());
        $faction->addClaim($claim);
        $this->saveFaction($faction);
        return true;
    }

    public function unclaimChunk(Faction $faction, string $world, int $chunkX, int $chunkZ): bool {
        $key = Claim::makeKey($world, $chunkX, $chunkZ);
        if (!$faction->hasClaim($key)) return false;
        $faction->removeClaim($key);
        $this->saveFaction($faction);
        return true;
    }

    public function unclaimAll(Faction $faction): void {
        foreach ($faction->getClaims() as $key => $claim) {
            $faction->removeClaim($key);
        }
        $this->saveFaction($faction);
    }

    // ─── Top Factions ──────────────────────────────────────────────────────────

    /**
     * Retorna top factions ordenadas por spawners
     * @return Faction[]
     */
    public function getTopBySpawners(int $limit = 10): array {
        $sorted = array_values($this->factions);
        usort($sorted, fn($a, $b) => $b->getSpawnerCount() <=> $a->getSpawnerCount());
        return array_slice($sorted, 0, $limit);
    }

    /**
     * Retorna top factions ordenadas por dinheiro
     * @return Faction[]
     */
    public function getTopByMoney(int $limit = 10): array {
        $sorted = array_values($this->factions);
        usort($sorted, fn($a, $b) => $b->getMoney() <=> $a->getMoney());
        return array_slice($sorted, 0, $limit);
    }

    /**
     * Retorna top factions ordenadas por kills
     * @return Faction[]
     */
    public function getTopByKills(int $limit = 10): array {
        $sorted = array_values($this->factions);
        usort($sorted, fn($a, $b) => $b->getKills() <=> $a->getKills());
        return array_slice($sorted, 0, $limit);
    }

    // ─── Persistência ──────────────────────────────────────────────────────────

    public function saveFaction(Faction $faction): void {
        $file = $this->dataPath . strtolower($faction->getName()) . ".json";
        file_put_contents($file, json_encode($faction->toArray(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    public function saveAll(): void {
        foreach ($this->factions as $faction) {
            $this->saveFaction($faction);
        }
    }

    private function loadAll(): void {
        $files = glob($this->dataPath . "*.json") ?: [];
        foreach ($files as $file) {
            $data = json_decode(file_get_contents($file), true);
            if (!is_array($data)) continue;
            $faction = Faction::fromArray($data);
            $this->factions[strtolower($faction->getName())] = $faction;
            foreach ($faction->getMembers() as $m) {
                $this->playerFaction[strtolower($m->getName())] = strtolower($faction->getName());
            }
        }
    }
}
