<?php

declare(strict_types=1);

namespace zPlugins\Factions\Manager;

use pocketmine\block\MonsterSpawner;
use pocketmine\block\tile\MobSpawner;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\World;
use zPlugins\Factions\Data\Faction;
use zPlugins\Factions\Main;

class SpawnerManager {

    private Main $plugin;

    // Limite de spawners para mostrar coordenadas (10kk = 10.000.000)
    private int $coordinateLimit;

    public function __construct(Main $plugin) {
        $this->plugin          = $plugin;
        $this->coordinateLimit = $plugin->getConfig()->getNested("spawners.coordinate_limit", 10000000);
    }

    /**
     * Registra um spawner na facção
     */
    public function registerSpawner(Faction $faction, string $type, int $x, int $y, int $z, string $world, int $count = 1): void {
        $faction->addSpawner($type, $x, $y, $z, $world, $count);
        $this->plugin->getFactionManager()->saveFaction($faction);
    }

    /**
     * Remove um spawner da facção
     */
    public function removeSpawner(Faction $faction, string $worldName, int $x, int $y, int $z): void {
        $key = "{$worldName}:{$x}:{$y}:{$z}";
        $faction->removeSpawner($key);
        $this->plugin->getFactionManager()->saveFaction($faction);
    }

    /**
     * Retorna o total de spawners de uma facção
     */
    public function getTotalSpawners(Faction $faction): int {
        return $faction->getSpawnerCount();
    }

    /**
     * Verifica se deve mostrar coordenadas (acima de 10kk)
     */
    public function shouldShowCoordinates(Faction $faction): bool {
        return $faction->getSpawnerCount() >= $this->coordinateLimit;
    }

    /**
     * Retorna lista formatada de spawners com coordenadas (se acima do limite)
     */
    public function getSpawnersFormatted(Faction $faction, bool $forceCoords = false): array {
        $lines  = [];
        $total  = 0;
        $showCoords = $forceCoords || $this->shouldShowCoordinates($faction);

        // Agrupa por tipo
        $byType = [];
        foreach ($faction->getSpawners() as $key => $spawner) {
            $type = $spawner["type"];
            if (!isset($byType[$type])) $byType[$type] = ["count" => 0, "positions" => []];
            $byType[$type]["count"] += $spawner["count"];
            $byType[$type]["positions"][] = [
                "x" => $spawner["x"],
                "y" => $spawner["y"],
                "z" => $spawner["z"],
                "world" => $spawner["world"]
            ];
            $total += $spawner["count"];
        }

        foreach ($byType as $type => $info) {
            $line = "§e" . ucfirst(strtolower($type)) . "§7: §f" . number_format($info["count"]);
            if ($showCoords && count($info["positions"]) > 0) {
                $pos   = $info["positions"][0];
                $line .= " §7[§bX:{$pos['x']} Y:{$pos['y']} Z:{$pos['z']}§7]";
            }
            $lines[] = $line;
        }

        return [
            "lines"       => $lines,
            "total"       => $total,
            "showCoords"  => $showCoords
        ];
    }

    /**
     * Retorna o tipo de spawner de um bloco (tile)
     */
    public function getSpawnerTypeFromBlock(World $world, Vector3 $pos): ?string {
        $tile = $world->getTileAt((int)$pos->x, (int)$pos->y, (int)$pos->z);
        if ($tile instanceof MobSpawner) {
            $spawnCompound = $tile->getSpawnCompound();
            if ($spawnCompound !== null) {
                return $spawnCompound->getString("id", "UNKNOWN");
            }
        }
        return null;
    }

    /**
     * Formata número grande (ex: 10000000 => 10kk)
     */
    public static function formatNumber(int $n): string {
        if ($n >= 1_000_000_000) return number_format($n / 1_000_000_000, 1) . "B";
        if ($n >= 1_000_000)     return number_format($n / 1_000_000, 1) . "kk";
        if ($n >= 1_000)         return number_format($n / 1_000, 1) . "k";
        return (string)$n;
    }

    /**
     * Verifica se um chunk é um Slime Chunk baseado na seed do mundo
     */
    public function isSlimeChunk(int $x, int $z, int $seed): bool {
        // Algoritmo clássico de Slime Chunk do Minecraft Java
        // (x * x * 0x4c1906 + x * 0x5ac0db + z * z * 0x4307a7 + z * 0x5f24f ^ 0x3ad8025f)
        $val = (int)($seed + 
            ($x * $x * 0x4c1906) + 
            ($x * 0x5ac0db) + 
            ($z * $z * 0x4307a7) + 
            ($z * 0x5f24f) ^ 0x3ad8025f);
        
        // Usar um gerador de números aleatórios determinístico baseado no valor calculado
        mt_srand($val);
        $isSlime = mt_rand(0, 9) === 0; // 10% de chance (1 em 10 chunks)
        mt_srand(); // Resetar o gerador global
        
        return $isSlime;
    }
}
