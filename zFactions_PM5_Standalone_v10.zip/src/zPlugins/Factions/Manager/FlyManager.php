<?php

declare(strict_types=1);

namespace zPlugins\Factions\Manager;

use pocketmine\player\Player;
use zPlugins\Factions\Data\Faction;
use zPlugins\Factions\Main;

class FlyManager {

    private Main $plugin;

    /** @var array<string, bool> jogadores com f-fly ativo */
    private array $flyEnabled = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    /**
     * Ativa/desativa o voo de facção para um jogador
     */
    public function toggleFly(Player $player): bool {
        $name = strtolower($player->getName());
        $fm   = $this->plugin->getFactionManager();

        // Verifica permissão
        if (!$player->hasPermission("zfactions.fly")) {
            $player->sendMessage("§cVocê precisa ser §eVIP §cpara usar o F-Fly!");
            return false;
        }

        // Verifica se está em facção
        $faction = $fm->getPlayerFaction($player->getName());
        if ($faction === null) {
            $player->sendMessage("§cVocê precisa estar em uma facção para usar o F-Fly!");
            return false;
        }

        // Verifica se está no claim da própria facção
        $pos   = $player->getPosition();
        $chunk = [
            "world"  => $pos->getWorld()->getFolderName(),
            "chunkX" => $pos->getFloorX() >> 4,
            "chunkZ" => $pos->getFloorZ() >> 4
        ];
        $claimFaction = $fm->getClaimAt($chunk["world"], $chunk["chunkX"], $chunk["chunkZ"]);

        if ($claimFaction === null || strtolower($claimFaction->getName()) !== strtolower($faction->getName())) {
            $player->sendMessage("§cVocê precisa estar no claim da sua facção para ativar o F-Fly!");
            return false;
        }

        if ($this->hasFly($player->getName())) {
            $this->disableFly($player);
            return false;
        } else {
            $this->enableFly($player, $faction);
            return true;
        }
    }

    public function enableFly(Player $player, Faction $faction): void {
        $name = strtolower($player->getName());
        $this->flyEnabled[$name] = true;
        $faction->addFlyPlayer($player->getName());
        $player->setAllowFlight(true);
        $player->setFlying(true);
        $player->sendMessage($this->plugin->getConfig()->getNested("messages.fly_enabled", "§aVoo de Facção §aativado!"));
        $this->sendHotbarMessage($player, $faction->getName());
    }

    public function disableFly(Player $player, bool $notify = true): void {
        $name    = strtolower($player->getName());
        $fm      = $this->plugin->getFactionManager();
        $faction = $fm->getPlayerFaction($player->getName());

        unset($this->flyEnabled[$name]);
        if ($faction !== null) $faction->removeFlyPlayer($player->getName());

        if (!$player->isCreative() && !$player->isSpectator()) {
            $player->setAllowFlight(false);
            $player->setFlying(false);
        }

        if ($notify) {
            $player->sendMessage($this->plugin->getConfig()->getNested("messages.fly_disabled", "§cVoo de Facção §cdesativado."));
        }
    }

    public function hasFly(string $playerName): bool {
        return $this->flyEnabled[strtolower($playerName)] ?? false;
    }

    /**
     * Verifica e ajusta o voo ao mudar de chunk
     */
    public function checkFlyOnChunkChange(Player $player, ?Faction $newClaimFaction): void {
        if (!$this->hasFly($player->getName())) return;

        $fm            = $this->plugin->getFactionManager();
        $playerFaction = $fm->getPlayerFaction($player->getName());

        if ($playerFaction === null) {
            $this->disableFly($player, false);
            $player->sendMessage($this->plugin->getConfig()->getNested("messages.fly_no_claim", "§cVocê saiu do claim! Voo desativado."));
            return;
        }

        $disableFly = $newClaimFaction === null ||
            strtolower($newClaimFaction->getName()) !== strtolower($playerFaction->getName());

        if ($disableFly && $this->plugin->getConfig()->getNested("fly.disable_outside_claim", true)) {
            $this->disableFly($player, false);
            $player->sendMessage($this->plugin->getConfig()->getNested("messages.fly_no_claim", "§cVocê saiu do claim! Voo desativado."));
        }
    }

    /**
     * Envia mensagem na hotbar do jogador
     */
    public function sendHotbarMessage(Player $player, string $factionName): void {
        $msg = $this->plugin->getConfig()->getNested("fly.hotbar_message", "§a✈ F-FLY §7| §eClaim: §f{faction}");
        $msg = str_replace("{faction}", $factionName, $msg);
        $player->sendTip($msg);
    }

    public function clearPlayer(string $playerName): void {
        unset($this->flyEnabled[strtolower($playerName)]);
    }
}
