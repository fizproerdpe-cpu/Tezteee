<?php

declare(strict_types=1);

namespace zPlugins\Factions\Manager;

use onebone\economyapi\EconomyAPI;
use pocketmine\player\Player;
use pocketmine\Server;
use zPlugins\Factions\Main;

class EconomyManager {

    private Main $plugin;
    private bool $economyEnabled = false;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
        $this->economyEnabled = $this->isEconomyAvailable();
    }

    public function isEconomyAvailable(): bool {
        return Server::getInstance()->getPluginManager()->getPlugin("EconomyAPI") !== null;
    }

    public function isEnabled(): bool {
        return $this->economyEnabled;
    }

    public function getMoney(Player $player): float {
        if (!$this->economyEnabled) return 0.0;
        return (float) EconomyAPI::getInstance()->myMoney($player);
    }

    public function getMoneyByName(string $name): float {
        if (!$this->economyEnabled) return 0.0;
        return (float) EconomyAPI::getInstance()->myMoney($name);
    }

    public function reduceMoney(Player $player, float $amount): bool {
        if (!$this->economyEnabled) return true;
        if ($this->getMoney($player) < $amount) return false;
        EconomyAPI::getInstance()->reduceMoney($player, $amount);
        return true;
    }

    public function addMoney(Player $player, float $amount): void {
        if (!$this->economyEnabled) return;
        EconomyAPI::getInstance()->addMoney($player, $amount);
    }

    public function formatMoney(float $amount): string {
        if ($amount >= 1_000_000_000) return "R$" . number_format($amount / 1_000_000_000, 2) . "B";
        if ($amount >= 1_000_000)     return "R$" . number_format($amount / 1_000_000, 2) . "kk";
        if ($amount >= 1_000)         return "R$" . number_format($amount / 1_000, 2) . "k";
        return "R$" . number_format($amount, 2);
    }
}
