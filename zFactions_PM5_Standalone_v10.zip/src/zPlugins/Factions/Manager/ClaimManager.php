<?php

declare(strict_types=1);

namespace zPlugins\Factions\Manager;

use pocketmine\math\Vector3;
use pocketmine\player\Player;
use pocketmine\world\Position;
use zPlugins\Factions\Data\Faction;
use zPlugins\Factions\Main;

class ClaimManager {

    private Main $plugin;

    /** @var array<string, bool> jogadores com auto-claim ativo */
    private array $autoClaiming = [];

    /** @var array<string, string> último chunk do jogador (para detecção de mudança) */
    private array $lastChunk = [];

    /** @var array<string, string> última facção do chunk onde o jogador estava */
    private array $lastFactionChunk = [];

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    // ─── Auto-Claim ────────────────────────────────────────────────────────────

    public function toggleAutoClaim(string $playerName): bool {
        $key = strtolower($playerName);
        $this->autoClaiming[$key] = !($this->autoClaiming[$key] ?? false);
        return $this->autoClaiming[$key];
    }

    public function isAutoClaiming(string $playerName): bool {
        return $this->autoClaiming[strtolower($playerName)] ?? false;
    }

    public function disableAutoClaim(string $playerName): void {
        unset($this->autoClaiming[strtolower($playerName)]);
    }

    // ─── Verificações de Chunk ─────────────────────────────────────────────────

    public function getChunkKey(string $world, int $chunkX, int $chunkZ): string {
        return "{$world}:{$chunkX}:{$chunkZ}";
    }

    public function getChunkFromPosition(Position $pos): array {
        return [
            "world"  => $pos->getWorld()->getFolderName(),
            "chunkX" => $pos->getFloorX() >> 4,
            "chunkZ" => $pos->getFloorZ() >> 4
        ];
    }

    /**
     * Verifica se o jogador pode construir/destruir nesse chunk
     */
    public function canBuild(Player $player, Position $pos): bool {
        // Admin bypass
        if ($player->hasPermission("zfactions.bypass")) return true;

        $fm = $this->plugin->getFactionManager();
        $chunk = $this->getChunkFromPosition($pos);
        $claimFaction = $fm->getClaimAt($chunk["world"], $chunk["chunkX"], $chunk["chunkZ"]);

        if ($claimFaction === null) return true; // Terreno livre

        $playerFaction = $fm->getPlayerFaction($player->getName());
        if ($playerFaction === null) return false; // Sem facção, não pode

        return strtolower($playerFaction->getName()) === strtolower($claimFaction->getName());
    }

    /**
     * Verifica se o jogador mudou de chunk e dispara eventos de entrada/saída
     */
    public function checkChunkChange(Player $player, Position $newPos): void {
        $name  = strtolower($player->getName());
        $chunk = $this->getChunkFromPosition($newPos);
        $key   = $this->getChunkKey($chunk["world"], $chunk["chunkX"], $chunk["chunkZ"]);

        if (($this->lastChunk[$name] ?? "") === $key) return;
        $this->lastChunk[$name] = $key;

        $fm            = $this->plugin->getFactionManager();
        $claimFaction  = $fm->getClaimAt($chunk["world"], $chunk["chunkX"], $chunk["chunkZ"]);
        $lastFaction   = $this->lastFactionChunk[$name] ?? null;
        $currentName   = $claimFaction ? strtolower($claimFaction->getName()) : null;

        if ($lastFaction !== $currentName) {
            // Saiu de um claim
            if ($lastFaction !== null) {
                $player->sendMessage($this->plugin->getConfig()->getNested("messages.leave_claim", "§7Saindo do território de §e{faction}")
                    ? str_replace("{faction}", $lastFaction, $this->plugin->getConfig()->getNested("messages.leave_claim", "§7Saindo do território de §e{faction}"))
                    : "§7Saindo do território de §e{$lastFaction}");

                // Desativa fly se saiu do claim da própria facção
                $this->plugin->getFlyManager()->checkFlyOnChunkChange($player, null);
            }

            // Entrou em um claim
            if ($claimFaction !== null) {
                $playerFaction = $fm->getPlayerFaction($player->getName());
                $color = "§c"; // Inimigo (Vermelho)
                
                if ($playerFaction !== null) {
                    if (strtolower($playerFaction->getName()) === strtolower($claimFaction->getName())) {
                        $color = "§a"; // Sua (Verde)
                    } elseif ($playerFaction->isAlly($claimFaction->getName())) {
                        $color = "§e"; // Aliado (Amarelo)
                    }
                }
                
                $msg = "{$color}[{$claimFaction->getName()}] §fEntrando no território de {$color}{$claimFaction->getName()}";
                $player->sendMessage($msg);

                // Ativa fly se for claim da própria facção
                $this->plugin->getFlyManager()->checkFlyOnChunkChange($player, $claimFaction);
            }

            $this->lastFactionChunk[$name] = $currentName;
        }

        // Auto-claim
        if ($this->isAutoClaiming($player->getName())) {
            $playerFaction = $fm->getPlayerFaction($player->getName());
            if ($playerFaction !== null) {
                $member = $playerFaction->getMember($player->getName());
                if ($member !== null && $member->canManage()) {
                    $result = $fm->claimChunk($playerFaction, $chunk["world"], $chunk["chunkX"], $chunk["chunkZ"]);
                    if ($result) {
                        $player->sendMessage("§aChunk §e({$chunk['chunkX']}, {$chunk['chunkZ']})§a reivindicado automaticamente!");
                    }
                }
            }
        }
    }

    public function clearPlayer(string $playerName): void {
        $key = strtolower($playerName);
        unset($this->lastChunk[$key], $this->lastFactionChunk[$key], $this->autoClaiming[$key]);
    }
}
