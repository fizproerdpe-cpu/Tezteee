<?php

declare(strict_types=1);

namespace zPlugins\Factions\Tasks;

use pocketmine\scheduler\Task;
use zPlugins\Factions\Main;

class FlyTask extends Task {

    private Main $plugin;

    public function __construct(Main $plugin) {
        $this->plugin = $plugin;
    }

    public function onRun(): void {
        $fm = $this->plugin->getFactionManager();
        $eco = $this->plugin->getEconomyManager();
        
        foreach ($this->plugin->getServer()->getOnlinePlayers() as $player) {
            $pos = $player->getPosition();
            $world = $pos->getWorld()->getFolderName();
            
            $claimFaction = $fm->getClaimAt($world, $pos->getFloorX() >> 4, $pos->getFloorZ() >> 4);
            $playerFaction = $fm->getPlayerFaction($player->getName());
            $member = $playerFaction ? $playerFaction->getMember($player->getName()) : null;
            
            // 1. Poder
            $power = $member ? number_format($member->getPower(), 1) : "10.0";
            
            // 2. Zona
            $spawnDist = sqrt(pow($pos->getX(), 2) + pow($pos->getZ(), 2));
            $zona = "§7Zona Livre";
            if ($spawnDist <= 100) {
                $zona = "§eSpawn Protegido";
            } elseif ($spawnDist <= 300) {
                $zona = "§cZona de Guerra";
            } elseif ($claimFaction !== null) {
                $color = "§c";
                if ($playerFaction !== null && strtolower($claimFaction->getName()) === strtolower($playerFaction->getName())) {
                    $color = "§a";
                } elseif ($playerFaction !== null && $playerFaction->isAlly($claimFaction->getName())) {
                    $color = "§e";
                }
                $zona = "{$color}Zona Protegida";
            }

            // 3. Facção (TAG e Nome)
            $fName = $playerFaction ? "§f" . $playerFaction->getName() : "§7Nenhuma";
            $fTag  = $playerFaction ? "§7[§e" . $playerFaction->getTag() . "§7]" : "";

            // 4. Coins (EconomyAPI)
            $coins = number_format($eco->getMoney($player->getName()), 0, ',', '.');

            // Construir a Hotbar empilhada (usando \n para quebras de linha)
            // No PocketMine, sendTip com \n exibe as linhas uma em cima da outra na hotbar
            $msg = "{$zona}\n" .
                   "§fFacção: {$fName} {$fTag}\n" .
                   "§fPoder: §e{$power}§7/§e10.0\n" .
                   "§fCoins: §a$ {$coins}";

            $player->sendTip($msg);
        }
    }
}
