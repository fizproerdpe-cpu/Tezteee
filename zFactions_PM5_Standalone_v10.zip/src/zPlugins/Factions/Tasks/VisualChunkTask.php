<?php

declare(strict_types=1);

namespace zPlugins\Factions\Tasks;

use pocketmine\scheduler\Task;
use pocketmine\world\particle\SmokeParticle;
use pocketmine\math\Vector3;
use pocketmine\player\Player;
use zPlugins\Factions\Main;

class VisualChunkTask extends Task {

    /** @var Player[] */
    private array $players = [];

    public function addPlayer(Player $player): void {
        $this->players[strtolower($player->getName())] = $player;
    }

    public function removePlayer(Player $player): void {
        unset($this->players[strtolower($player->getName())]);
    }

    public function isViewing(Player $player): bool {
        return isset($this->players[strtolower($player->getName())]);
    }

    public function onRun(): void {
        foreach ($this->players as $name => $player) {
            if (!$player->isOnline()) {
                unset($this->players[$name]);
                continue;
            }

            $pos = $player->getPosition();
            $world = $pos->getWorld();
            $minX = ($pos->getFloorX() >> 4) << 4;
            $minZ = ($pos->getFloorZ() >> 4) << 4;
            $maxX = $minX + 16;
            $maxZ = $minZ + 16;

            $isSlime = Main::getInstance()->getSpawnerManager()->isSlimeChunk($pos->getFloorX() >> 4, $pos->getFloorZ() >> 4, (int)$world->getSeed());
            
            // Partícula Verde para Slime Chunk, Branca para Normal
            $particle = $isSlime ? new \pocketmine\world\particle\DustParticle(new \pocketmine\color\Color(0, 255, 0)) : new SmokeParticle();
            $y = $pos->getY() + 0.5;

            if ($isSlime) $player->sendTip("§a§l[Slime Chunk Detectada!]");

            // Desenhar bordas do chunk
            for ($x = $minX; $x <= $maxX; $x += 2) {
                $world->addParticle(new Vector3($x, $y, $minZ), $particle, [$player]);
                $world->addParticle(new Vector3($x, $y, $maxZ), $particle, [$player]);
            }
            for ($z = $minZ; $z <= $maxZ; $z += 2) {
                $world->addParticle(new Vector3($minX, $y, $z), $particle, [$player]);
                $world->addParticle(new Vector3($maxX, $y, $z), $particle, [$player]);
            }
        }
    }
}
