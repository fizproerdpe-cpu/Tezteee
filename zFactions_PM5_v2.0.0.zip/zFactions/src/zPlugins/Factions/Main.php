<?php

namespace zPlugins\Factions;

use pocketmine\plugin\PluginBase;
use pocketmine\player\Player;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\utils\Config;
use muqsit\invmenu\InvMenuHandler;

class Main extends PluginBase implements Listener {

    private static $instance;
    private $factions;
    private $claims;
    private $power;
    private $scoreboard;

    public function onEnable(): void {
        self::$instance = $this;
        $this->saveDefaultConfig();
        
        // Inicialização do InvMenu
        if(!InvMenuHandler::isRegistered()){
            InvMenuHandler::register($this);
        }

        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        
        $this->factions = new Config($this->getDataFolder() . "factions.json", Config::JSON);
        $this->claims = new Config($this->getDataFolder() . "claims.json", Config::JSON);
        
        $this->getLogger()->info("§a[zFactions] Plugin v2.0.0 ativado com sucesso!");
    }

    public static function getInstance(): self {
        return self::$instance;
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args): bool {
        if(!$sender instanceof Player) return false;

        if($command->getName() === "f"){
            if(empty($args)){
                // Abrir UI de Windows/Forms se o player não digitar nada
                $this->openFactionsMenu($sender);
                return true;
            }

            switch(strtolower($args[0])){
                case "top":
                    $this->openTopRanking($sender);
                    break;
                case "claim":
                    $this->claimTerritory($sender);
                    break;
                case "home":
                    $this->teleportHome($sender);
                    break;
                default:
                    $sender->sendMessage("§cUse /f para abrir o menu.");
                    break;
            }
        }
        return true;
    }

    // Sistema de Chat Colorido para o Imperador (Top #1)
    public function onChat(PlayerChatEvent $event): void {
        $player = $event->getPlayer();
        // Lógica de verificação do Top 1
        $topFaction = "Exemplo"; // Aqui entraria a lógica de ranking
        $isLeader = true; // Aqui a verificação do líder

        if($isLeader && $topFaction === "Vencedora"){
             $event->setFormat("§b§l[IMPERADOR] §r" . $player->getDisplayName() . ": §b§l" . $event->getMessage());
        }
    }

    private function openFactionsMenu(Player $player): void {
        // Lógica de envio de Forms/Windows UI
        $player->sendMessage("§eAbrindo menu de Facções...");
    }

    private function openTopRanking(Player $player): void {
        // Lógica de InvMenu para o Ranking
        $player->sendMessage("§aAbrindo Ranking via InvMenu...");
    }

    private function claimTerritory(Player $player): void {
        // Lógica de Claim baseada em Chunks
        $player->sendMessage("§6Chunk protegido com sucesso!");
    }
}
